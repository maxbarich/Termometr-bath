//
//  bme280.c
//  i2c
//
//  Created by Michael Köhler on 09.10.17.
//
//

#include "bme280.h"
#include <math.h>       // for NAN

void bme280_init(void){
    if (bme280_read1Byte(BME280_REGISTER_CHIPID) == 0x60){
        // configure sensor
        i2c__start(BME_ADDR);

        i2c_byte(BME280_REGISTER_CONFIG);
        i2c_byte(BME280_CONFIG);
 #ifdef BMP280
        i2c_byte(BME280_REGISTER_CONTROLHUMID);
        i2c_byte(BME280_HUM_CONFIG);
#endif       
        i2c_byte(BME280_REGISTER_CONTROL);
        i2c_byte((BME280_TEMP_CONFIG << 5)|(BME280_PRESS_CONFIG << 2)|(BME280_MODE_CONFIG));
        
        i2c__stop();
        
		// read coefficients
        bme280_readCoefficients();
    }
}

/*
float bme280_readTemperature(void){
    uint32_t adc_T  = bme280_read3Byte(BME280_REGISTER_TEMPDATA);
   // if (adc_T == 0x800000) // value in case pressure measurement was disabled
   //     return NAN;
    int32_t var1, var2;
float T ;
  //  adc_T = bme280_read3Byte(BME280_REGISTER_TEMPDATA);
    
    adc_T >>= 4;
    
    var1  = ((((adc_T>>3) - ((int32_t)_bme280_calib.dig_T1 <<1))) *
             ((int32_t)_bme280_calib.dig_T2)) >> 11;
    
    var2  = (((((adc_T>>4) - ((int32_t)_bme280_calib.dig_T1)) *
               ((adc_T>>4) - ((int32_t)_bme280_calib.dig_T1))) >> 12) *
             ((int32_t)_bme280_calib.dig_T3)) >> 14;
    
    t_fine = var1 + var2;
   // float T  = (t_fine * 5 + 128) >> 8;
     T  = (t_fine * 5 + 128) >> 8;
    
    return T/100;
}*/
float bme280_readTemperature(void){
    float PS1T_Raw  = bme280_read3Byte(BME280_REGISTER_TEMPDATA);
    float var1, var2;
float T ;
     PS1T_Raw = 522077;
     printf(" T =%ul",PS1T_Raw);
    var1=(PS1T_Raw/16384.0-_bme280_calib.dig_T1/1024.0)*_bme280_calib.dig_T2;
    var2=((PS1T_Raw/131072.0-_bme280_calib.dig_T1/8192.0)*(PS1T_Raw/131072.0-_bme280_calib.dig_T1/8192.0))*_bme280_calib.dig_T3;
    t_fine=var1+var2;
    return t_fine/5120.0;

}

/*float bme280_readPressure(void){
    int64_t var1, var2, p;
    
    bme280_readTemperature(); // must be done first to get t_fine
    
    int32_t adc_P = bme280_read3Byte(BME280_REGISTER_PRESSUREDATA);
    if (adc_P == 0x800000) // value in case pressure measurement was disabled
        return NAN;
    adc_P >>= 4;
    
    var1 = ((int64_t)t_fine) - 128000ul;
    var2 = var1 * var1 * (int64_t)_bme280_calib.dig_P6;
    var2 = var2 + ((var1*(int64_t)_bme280_calib.dig_P5)<<17);
    var2 = var2 + (((int64_t)_bme280_calib.dig_P4)<<35);
    var1 = ((var1 * var1 * (int64_t)_bme280_calib.dig_P3)>>8) +
    ((var1 * (int64_t)_bme280_calib.dig_P2)<<12);
    var1 = (((((int64_t)1)<<47)+var1))*((int64_t)_bme280_calib.dig_P1)>>33;
    
    if (var1 == 0) {
        return 0; // avoid exception caused by division by zero
    }
    p = 1048576ul - adc_P;
    p = (((p<<31) - var2)*3125ul) / var1;
    var1 = (((int64_t)_bme280_calib.dig_P9) * (p>>13) * (p>>13)) >> 25;
    var2 = (((int64_t)_bme280_calib.dig_P8) * p) >> 19;
    
    p = ((p + var1 + var2) >> 8) + (((int64_t)_bme280_calib.dig_P7)<<4);
    return (float)p/256ul;
}
*/


float bme280_readPressure(void){
    float var1, var2, p;
    float adc_P;
    
    bme280_readTemperature(); // must be done first to get t_fine
    
     adc_P = bme280_read3Byte(BME280_REGISTER_PRESSUREDATA);
     // printf("P=%ul",adc_P);
   // if (adc_P == 0x800000) // value in case pressure measurement was disabled
   //     return NAN;
    adc_P /=16;
    adc_P = 375902;
    t_fine = 117779;
    printf(" P =%ul",adc_P);
    var1 = (t_fine) - 128000.0;
    var2 = var1 * var1 * _bme280_calib.dig_P6;
    var2 = var2 + ((var1*_bme280_calib.dig_P5)*131072.0);
    var2 = var2 + ((_bme280_calib.dig_P4)*34359738368.0);
    var1 = ((var1 * var1 * _bme280_calib.dig_P3)/256) +
    ((var1 * _bme280_calib.dig_P2)*4096);   ;
    var1 = ((((1)*140737488355328.0)+var1))*(_bme280_calib.dig_P1)/8589934592.0;
    
    if (var1 == 0) {
        return 0; // avoid exception caused by division by zero
    }
    p = 1048576.0 - adc_P;
    p = (((p*2147483648.0) - var2)*3125.0) / var1;
    var1 = ((_bme280_calib.dig_P9) * (p/8192) * (p/8192)) /33554432.0;
    var2 = ((_bme280_calib.dig_P8) * p) /524288.0;
    
    p = ((p + var1 + var2) /256) + (( (float)_bme280_calib.dig_P7)*16); 
    return (float)p/256.0;
} 
/*
float bme280_readPressure(void){
    float var1, var2;//, p;
    float PS1P_Raw,PS1P_Cmp;
    
    bme280_readTemperature(); // must be done first to get t_fine
    PS1P_Raw = bme280_read3Byte(BME280_REGISTER_PRESSUREDATA)/16;
    printf("Praw=%ul",(long)PS1P_Raw);
    var1=(t_fine/2.0)-64000.0;
    var2=var1*var1*_bme280_calib.dig_P6/32768.0;
    var2=var2+var1*_bme280_calib.dig_P5*2.0;
    var2=(var2/4.0)+(_bme280_calib.dig_P4*65536.0);
    var1=(_bme280_calib.dig_P3*var1*var1/524288.0+_bme280_calib.dig_P2*var1)/524288.0;
    var1=(1.0+var1/32768.0)*_bme280_calib.dig_P1;
    PS1P_Cmp=1048576.0-PS1P_Raw;
    PS1P_Cmp=(PS1P_Cmp-(var2/4096.0))*6250.0/var1;
    var1=_bme280_calib.dig_P9*PS1P_Cmp*PS1P_Cmp/2147483648.0;
    var2=PS1P_Cmp*_bme280_calib.dig_P8/32768.0;
    PS1P_Cmp=PS1P_Cmp+(var1+var2+_bme280_calib.dig_P7)/16.0;
//    PS1PmmHg_Cmp=PS1P_Cmp/100*0.750063755419211;
    return PS1P_Cmp/100*0.750063755419211;
}
*/    

#ifdef BME280
float bme280_readHumidity(void){
    int32_t adc_H;
    int32_t v_x1_u32r;
    float h;
        bme280_readTemperature(); // must be done first to get t_fine
    
     adc_H = bme280_read2Byte(BME280_REGISTER_HUMIDDATA);
//    if (adc_H == 0x8000) // value in case humidity measurement was disabled
//        return NAN;
    
    v_x1_u32r = (t_fine - ((int32_t)76800));
    
    v_x1_u32r = (((((adc_H << 14) - (((int32_t)_bme280_calib.dig_H4) << 20) -
                    (((int32_t)_bme280_calib.dig_H5) * v_x1_u32r)) + ((int32_t)16384)) >> 15) *
                 (((((((v_x1_u32r * ((int32_t)_bme280_calib.dig_H6)) >> 10) *
                      (((v_x1_u32r * ((int32_t)_bme280_calib.dig_H3)) >> 11) + ((int32_t)32768))) >> 10) +
                    ((int32_t)2097152)) * ((int32_t)_bme280_calib.dig_H2) + 8192) >> 14));
    
    v_x1_u32r = (v_x1_u32r - (((((v_x1_u32r >> 15) * (v_x1_u32r >> 15)) >> 7) *
                               ((int32_t)_bme280_calib.dig_H1)) >> 4));
    
    v_x1_u32r = (v_x1_u32r < 0) ? 0 : v_x1_u32r;
    v_x1_u32r = (v_x1_u32r > 419430400) ? 419430400 : v_x1_u32r;
     h = (v_x1_u32r>>12);
    return  h / 1024.0;
    
}
#endif

/*   
float bme280_readHumidity(void){
    float var1, var2;//, p;
    float PS1H_Raw,PS1H_Cmp;
    
    PS1H_Cmp=t_fine-76800.0;
    PS1H_Cmp=(PS1H_Raw-(_bme280_calib.dig_H4*64.0+_bme280_calib.dig_H5/16384.0*PS1H_Cmp))*
    (_bme280_calib.dig_H2/65536.0*(1.0+_bme280_calib.dig_H6/67108864.0*PS1H_Cmp*(1.0+_bme280_calib.dig_H3/67108864.0*PS1H_Cmp)));
    PS1H_Cmp=PS1H_Cmp*(1.0-_bme280_calib.dig_H1*PS1H_Cmp/524288.0);
    
}
*/
/*float bme280_readAltitude(float seaLevel){
    // seaLevel at hPa (mBar), equation from datasheet BMP180, page 16
    
    float atmospheric = bme280_readPressure() / 100.0F;
    return 44330.0 * (1.0 - pow(atmospheric / seaLevel, 0.1903));
}*/

uint8_t bme280_read1Byte(uint8_t addr){
    uint8_t value;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readNAck();
    i2c__stop();
    return value;
}
uint16_t bme280_read2Byte(uint8_t addr){
    uint16_t value;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readAck();
    value <<= 8;
    value |= i2c_readNAck();
    i2c__stop();
    return value;
}
uint32_t bme280_read3Byte(uint8_t addr){
    uint32_t value;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readAck();
    value <<= 8;
    value |= i2c_readAck();
    value <<= 8;
    value |= i2c_readNAck();
    i2c__stop();
    return value;
}
uint16_t read16_LE(uint8_t reg)
{
    uint16_t temp = bme280_read2Byte(reg);
    return (temp >> 8) | (temp << 8);
    
}

int16_t readS16(uint8_t reg)
{
    return (int16_t)bme280_read2Byte(reg);
    
}

int16_t readS16_LE(uint8_t reg)
{
    return (int16_t)read16_LE(reg);
    
}


void bme280_readCoefficients(void)
{
    _bme280_calib.dig_T1 = read16_LE(BME280_REGISTER_DIG_T1);
    _bme280_calib.dig_T2 = readS16_LE(BME280_REGISTER_DIG_T2);
    _bme280_calib.dig_T3 = readS16_LE(BME280_REGISTER_DIG_T3);
    
    _bme280_calib.dig_P1 = read16_LE(BME280_REGISTER_DIG_P1);
    _bme280_calib.dig_P2 = readS16_LE(BME280_REGISTER_DIG_P2);
    _bme280_calib.dig_P3 = readS16_LE(BME280_REGISTER_DIG_P3);
    _bme280_calib.dig_P4 = readS16_LE(BME280_REGISTER_DIG_P4);
    _bme280_calib.dig_P5 = readS16_LE(BME280_REGISTER_DIG_P5);
    _bme280_calib.dig_P6 = readS16_LE(BME280_REGISTER_DIG_P6);
    _bme280_calib.dig_P7 = readS16_LE(BME280_REGISTER_DIG_P7);
    _bme280_calib.dig_P8 = readS16_LE(BME280_REGISTER_DIG_P8);
    _bme280_calib.dig_P9 = readS16_LE(BME280_REGISTER_DIG_P9);
#ifdef BME280
    _bme280_calib.dig_H1 = bme280_read1Byte(BME280_REGISTER_DIG_H1);
    _bme280_calib.dig_H2 = readS16_LE(BME280_REGISTER_DIG_H2);
    _bme280_calib.dig_H3 = bme280_read1Byte(BME280_REGISTER_DIG_H3);
    _bme280_calib.dig_H4 = (bme280_read1Byte(BME280_REGISTER_DIG_H4) << 4) | (bme280_read1Byte(BME280_REGISTER_DIG_H4+1) & 0xF);
    _bme280_calib.dig_H5 = (bme280_read1Byte(BME280_REGISTER_DIG_H5+1) << 4) | (bme280_read1Byte(BME280_REGISTER_DIG_H5) >> 4);
    _bme280_calib.dig_H6 = (int8_t)bme280_read1Byte(BME280_REGISTER_DIG_H6);
#endif
}
