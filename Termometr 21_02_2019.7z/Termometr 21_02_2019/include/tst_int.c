#define HALT while(1);

#define F_CPU 8000000UL 
#define __AVR_ATmega168PA__

//#include <mega88a.h>
#include <mega168pa.h>
#include <delay.h>
//#include "\include\i2cc.h"
//#include <io.h>
//#include "\include\twi.h"
//#include "\include\Si7021.h"
#include <stdio.h>
#include <stdlib.h>
//#include "\include\i2c.h"
//#include "\include\i2c.c"
//#include "\include\bme280.c"
//#include "\include\Si7021.c"
#include "\include\ini_timers.c"
char s[16];

char i;

int timer_s=0;
char f1ms=0;


#define LED PORTD.5
#define LED1 PORTD.6

void initusart(void)
{
//#include "\inc\initusart.c"
// USART initialization

#define FT F_CPU
#define BAUDRATE 9600 //4800 min ��� 20���(����� N35>256)
UCSR0A=0x00;
UCSR0C=0x06;
UCSR0B=0
//    |(1<<_D0)
//    |(1<<_D1)
//    |(1<<_D2)
    |(1<<3) //TX ENABLE
    |(1<<4) //RX ENABLE
//    |(1<<_D5) //UDR EMPTY INT EN
//    |(1<<_D6) //TX COMPLETE INT EN
//    |(1<<_D7) //RX COMPLETE INT EN
    ;

UBRR0H=(FT/16/BAUDRATE -1)>>8;
UBRR0L=FT/16/BAUDRATE -1;//25;

}
void port_ini(void)
{
PORTD = 0x00;
DDRD=0xff; //f9;
PORTB = 0x00;
DDRB=0xFF;
PORTC=0
    |(1<<0) //����� �������
    |(1<<1) //����� ������
//    |(1<<2) //
//    |(1<<3) //
//    |(1<<4) //
//    |(1<<5) //
//    |(1<<6) //
//    |(1<<7) //
    ;
DDRC=0
    |(1<<0) // ����� �������
    |(1<<1) // ����� ������ p-up
//    |(1<<2) //
//    |(1<<3) //
//    |(1<<4) //
//    |(1<<5) //
//    |(1<<6) //
//    |(1<<7) //
    ;

}



//#include "\include\test.c"

//------


interrupt [TIM0_COMPA] void t_coma(void)
{
//static int ct_ms;
//ct_ms++;
LED^=1;
f1ms=1;
//LED^=f1ms;
}

interrupt [TIM0_OVF] void t_ovf(void)
{
f1ms=1;
}
interrupt [EXT_INT0] void int_0(void)
{

}


void my_delay_ms(int t)
{
int tk;
#asm ("sei")

//LED=1;
do{
    while(f1ms==0)
    {//printf("TCNT0=%d TIFR0=%d f1ms=%d ",TCNT0,TIFR0,f1ms );
    //    f1ms=0;
//    LED=0;
//  LED1^=1;
    }
    f1ms=0;
  }while (t--);

//LED=1;
LED^=1;


}



// *****************************************
void main(void)
  {  


 port_ini();

// initusart();
 ini_timers();
f1ms=1; 
//LED=f1ms;
// LED=1;
//delay_ms(2000);


while(1)
{
//LED=(TCNT0<0x80);
my_delay_ms(200);

delay_ms(200);
// LED=1;
//delay_ms(500);
}


}
