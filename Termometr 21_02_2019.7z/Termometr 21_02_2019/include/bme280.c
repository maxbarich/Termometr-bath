//
//  bme280.c
//  i2c

#include "bme280.h"
#include <math.h>       // for NAN
unsigned char data280[8];

#define P280DATA 0
#define T280DATA 3
#define H280DATA 6
//#define bme280_get3Byte(a) (  ( (data280[a]<<16)|(data280[a+1]<<8)|(data280[a+2]) )>>4);
//#define bme280_get2Byte(a) ( (data280[a]<<8)|(data280[a+1]) );

extern char s[16];
void prnf(float f)
{
ftoa(f,3,s);
printf(" f=%s ",s);

}


void read_data280(void)
{
char i;
    i2c__start(BME_ADDR);
    i2c_byte(BME280_REGISTER_PRESSUREDATA);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
for(i=0;i<7;++i)
    {
    data280[i] = i2c_readAck();
    }
data280[i] = i2c_readNAck();

i2c__stop();
}


/*uint32_t bme280_get3Byte(char a)
{
uint32_t res;char i;
//res=( (data280[a]<<16)|(data280[a+1]<<8)|(data280[a+2]) );
printf("res= ");
res=data280[a];printf("%x ",res);res<<=8;
res|=data280[a+1];printf("%x ",res);res<<=8;
res|=data280[a+2];printf("%x ",res);
printf("registers= ");
for (i=0;i<8;++i)printf("%x ",data280[i]);

res>>=4;
printf("ret=%x ",res);
return res;
}
*/
uint32_t bme280_get3Byte(char a)
{
uint32_t res;char i;
//res=( (data280[a]<<16)|(data280[a+1]<<8)|(data280[a+2]) );
res=data280[a]; res<<=8;
res|=data280[a+1]; res<<=8;
res|=data280[a+2];

for (i=0;i<8;++i);

res>>=4;
return res;
}


uint32_t bme280_get2Byte(char a)
{
uint32_t res;//char i;
res=data280[a];res<<=8;
res|=data280[a+1];
//printf("ret=%x ",res);
return res;


}

float bme280_readTemperature(void){
    float PS1T_Raw ;// = bme280_read3Byte(BME280_REGISTER_TEMPDATA);
    float var1, var2;
float t ;//long t280;
PS1T_Raw=bme280_get3Byte(T280DATA);
//     printf(" PS1T_Raw =%u",(unsigned long)(PS1T_Raw/256) );
//prnf(PS1T_Raw);
   // PS1T_Raw = 522077;
    //PS1T_Raw = 558401;
    var1=(PS1T_Raw/16384.0-_bme280_calib.dig_T1/1024.0)*_bme280_calib.dig_T2;
    var2=((PS1T_Raw/131072.0-_bme280_calib.dig_T1/8192.0)*(PS1T_Raw/131072.0-_bme280_calib.dig_T1/8192.0))*_bme280_calib.dig_T3;
    t_fine=var1+var2;
//     printf(" Tt_fine =%ul #",(unsigned long)(t_fine) );
prnf(t_fine/5120.0);
    t= t_fine/5120.0; 
   // printf(" t =%ul",(int)t);
    return t;

}

void bme280_init(void){
    if (bme280_read1Byte(BME280_REGISTER_CHIPID) == 0x60){
        // configure sensor
        i2c__start(BME_ADDR);

        i2c_byte(BME280_REGISTER_CONFIG);
        i2c_byte(BME280_CONFIG);
 #ifdef BME280
        i2c_byte(BME280_REGISTER_CONTROLHUMID);
        i2c_byte(BME280_HUM_CONFIG);
#endif       
        i2c_byte(BME280_REGISTER_CONTROL);
        i2c_byte((BME280_TEMP_CONFIG << 5)|(BME280_PRESS_CONFIG << 2)|(BME280_MODE_CONFIG));//(BME280_TEMP_CONFIG << 5)|
        
        i2c__stop();
        
		// read coefficients
        bme280_readCoefficients();
    }
else printf("no 280 init");
}



float bme280_readPressure(void){
    float var1, var2;//, p;
    float PS1P_Raw,PS1P_Cmp;
    
//    bme280_readTemperature(); // must be done first to get t_fine
//    PS1P_Raw = bme280_read3Byte(BME280_REGISTER_PRESSUREDATA)/16;
PS1P_Raw=bme280_get3Byte(P280DATA);
    
   //PS1P_Raw = 375902;
   //t_fine = 117779;
    var1=(t_fine/2.0)-64000.0;
    var2=var1*var1*_bme280_calib.dig_P6/32768.0;
    var2=var2+var1*_bme280_calib.dig_P5*2.0;
    var2=(var2/4.0)+(_bme280_calib.dig_P4*65536.0);
    var1=(_bme280_calib.dig_P3*var1*var1/524288.0+_bme280_calib.dig_P2*var1)/524288.0;
    var1=(1.0+var1/32768.0)*_bme280_calib.dig_P1;
    PS1P_Cmp=1048576.0-PS1P_Raw;
    PS1P_Cmp=(PS1P_Cmp-(var2/4096.0))*6250.0/var1;
    var1=_bme280_calib.dig_P9*PS1P_Cmp*PS1P_Cmp/2147483648.0;
    var2=PS1P_Cmp*_bme280_calib.dig_P8/32768.0;
    PS1P_Cmp=PS1P_Cmp+(var1+var2+_bme280_calib.dig_P7)/16.0;
//    PS1PmmHg_Cmp=PS1P_Cmp/100*0.750063755419211;
    return PS1P_Cmp/100*0.750063755419211;
}
    

   
float bme280_readHumidity(void){
    float var1, var2;//, p;
    float PS1H_Raw,PS1H_Cmp;
    
   PS1H_Raw = bme280_get2Byte(H280DATA);
//   t_fine = 117779;     
    PS1H_Cmp=t_fine-76800.0;
    PS1H_Cmp=(PS1H_Raw-(_bme280_calib.dig_H4*64.0+_bme280_calib.dig_H5/16384.0*PS1H_Cmp))*
    (_bme280_calib.dig_H2/65536.0*(1.0+_bme280_calib.dig_H6/67108864.0*PS1H_Cmp*(1.0+_bme280_calib.dig_H3/67108864.0*PS1H_Cmp)));
    PS1H_Cmp=PS1H_Cmp*(1.0-_bme280_calib.dig_H1*PS1H_Cmp/524288.0);
    return PS1H_Cmp;
}

/*float bme280_readAltitude(float seaLevel){
    // seaLevel at hPa (mBar), equation from datasheet BMP180, page 16
    
    float atmospheric = bme280_readPressure() / 100.0F;
    return 44330.0 * (1.0 - pow(atmospheric / seaLevel, 0.1903));
}*/

uint8_t bme280_read1Byte(uint8_t addr){
    uint8_t value;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readNAck();
    i2c__stop();
    return value;
}
uint16_t bme280_read2Byte(uint8_t addr){
    uint16_t value;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readAck();
    value <<= 8;
    value |= i2c_readNAck();
    i2c__stop();
    return value;
}
uint32_t bme280_read3Byte(uint8_t addr){
    uint32_t value=0;
    i2c__start(BME_ADDR);
    i2c_byte(addr);
    i2c__stop();
    i2c__start(BME_ADDR|0x01);
    value = i2c_readAck();
    value <<= 8;
    value |= i2c_readAck();
    value <<= 8;
    value |= i2c_readNAck();
    i2c__stop();
    return value;
}
uint16_t read16_LE(uint8_t reg)
{
    uint16_t temp = bme280_read2Byte(reg);
    return (temp >> 8) | (temp << 8);
    
}

int16_t readS16(uint8_t reg)
{
    return (int16_t)bme280_read2Byte(reg);
    
}

int16_t readS16_LE(uint8_t reg)
{
    return (int16_t)read16_LE(reg);
    
}


void bme280_readCoefficients(void)
{
    _bme280_calib.dig_T1 = read16_LE(BME280_REGISTER_DIG_T1);
    _bme280_calib.dig_T2 = readS16_LE(BME280_REGISTER_DIG_T2);
    _bme280_calib.dig_T3 = readS16_LE(BME280_REGISTER_DIG_T3);
    
    _bme280_calib.dig_P1 = read16_LE(BME280_REGISTER_DIG_P1);
    _bme280_calib.dig_P2 = readS16_LE(BME280_REGISTER_DIG_P2);
    _bme280_calib.dig_P3 = readS16_LE(BME280_REGISTER_DIG_P3);
    _bme280_calib.dig_P4 = readS16_LE(BME280_REGISTER_DIG_P4);
    _bme280_calib.dig_P5 = readS16_LE(BME280_REGISTER_DIG_P5);
    _bme280_calib.dig_P6 = readS16_LE(BME280_REGISTER_DIG_P6);
    _bme280_calib.dig_P7 = readS16_LE(BME280_REGISTER_DIG_P7);
    _bme280_calib.dig_P8 = readS16_LE(BME280_REGISTER_DIG_P8);
    _bme280_calib.dig_P9 = readS16_LE(BME280_REGISTER_DIG_P9);
#ifdef BME280
    _bme280_calib.dig_H1 = bme280_read1Byte(BME280_REGISTER_DIG_H1);
    _bme280_calib.dig_H2 = readS16_LE(BME280_REGISTER_DIG_H2);
    _bme280_calib.dig_H3 = bme280_read1Byte(BME280_REGISTER_DIG_H3);
    _bme280_calib.dig_H4 = (bme280_read1Byte(BME280_REGISTER_DIG_H4) << 4) | (bme280_read1Byte(BME280_REGISTER_DIG_H4+1) & 0xF);
    _bme280_calib.dig_H5 = (bme280_read1Byte(BME280_REGISTER_DIG_H5+1) << 4) | (bme280_read1Byte(BME280_REGISTER_DIG_H5) >> 4);
    _bme280_calib.dig_H6 = (int8_t)bme280_read1Byte(BME280_REGISTER_DIG_H6);
#endif
}
