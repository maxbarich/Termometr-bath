#define HALT while(1);

#define F_CPU 8000000UL 
#define __AVR_ATmega168PA__

#include <mega168a.h>
#include <delay.h>
#include <lcd.c>
//#include "\include\i2cc.h"
//#include <io.h>
//#include "\include\twi.h"
//#include "\include\Si7021.h"
#include <stdio.h>
#include <stdlib.h>
#include "\include\i2c.h"
#include "\include\i2c.c"
#include "\include\bme280.c"
#include "\include\Si7021.c"
#include "\include\ini_timers.c"
char s[16];

char i;
bit f1ms=0,f_tm_on;
char  timer_s=0,timer_m=0;//������ ��� ���


void initusart(void);


void initusart(void)
{
//#include "\inc\initusart.c"
// USART initialization

#define FT F_CPU
#define BAUDRATE 9600 //4800 min ��� 20���(����� N35>256)
UCSR0A=0x00;
UCSR0C=0x06;
UCSR0B=0
//    |(1<<_D0)
//    |(1<<_D1)
//    |(1<<_D2)
    |(1<<3) //TX ENABLE
    |(1<<4) //RX ENABLE
//    |(1<<_D5) //UDR EMPTY INT EN
//    |(1<<_D6) //TX COMPLETE INT EN
//    |(1<<_D7) //RX COMPLETE INT EN
    ;

UBRR0H=(FT/16/BAUDRATE -1)>>8;
UBRR0L=FT/16/BAUDRATE -1;//25;

}
//------
#define KEY PINC.1
#define BUZER PORTC.0
#define BUZER_ON 1
#define BUZER_OFF 0
#define KEY_PRESS 0

void port_ini(void)
{
PORTD = 0x00;
DDRD=0xFF;
PORTB = 0x00;
DDRB=0xFF;

#define LED PORTB.5

PORTC=0
//    |(1<<0) //����� �������
    |(1<<1) //����� ������
//    |(1<<2) //
//    |(1<<3) //
//    |(1<<4) //
//    |(1<<5) //
//    |(1<<6) //
//    |(1<<7) //
    ;
DDRC=0
    |(1<<0) // ����� �������
    |(0<<1) // ����� ������ p-up
//    |(1<<2) //
//    |(1<<3) //
//    |(1<<4) //
//    |(1<<5) //
//    |(1<<6) //
//    |(1<<7) //
    ;

}


//------
void DisplayClear(void) // ������� �������
{
  sendbyte(1,0);
  delay_ms(10);
}

void LCD_Custom_Char (flash unsigned char *msg) // 8 �������� � �������
{
    unsigned char i;
    
    {
         sendbyte (0x40,0 );    /* Command 0x40 and onwards forces the device to point CGRAM address */
        for(i=0;i<64;i++)
        {    
        sendchar(msg[i]);
        }
    }
 sendbyte (0x80,0);
}


void lcd_text (char x,char y, char pos,flash char* text )
{
    DisplayClear();
    LCD_Custom_Char((flash char*)Character[pos]);
    setpos(x,y);
    lcd_rus(text);
 }
//--------

//#include "\include\test.c"

//------
void TimerView(void)

 {  unsigned char i;
 
    { 
        //������
        lcd_text(4,0,39, "Ta\0\1ep$");
        //while(1);
        setpos(6,1);
        //while(1);
        lcd_rus ("15$"); 
    } 
 }
//--------------------



interrupt [TIM0_COMPA] void t_coma(void)
{
static int ct_ms;

f1ms = 1;
if(++ct_ms>=1000)
    {ct_ms=0;
    if(f_tm_on)
        {if(timer_s-- == 0)
            { timer_s=59;
            if(timer_m)timer_m--;
            else f_tm_on=0;
            }
        if( (timer_m==0)&&(timer_s<10) )
            BUZER=(timer_s & 1);
        
        }
            
    }
//LED=1;//f1ms;
}

interrupt [TIM0_OVF] void t_ovf(void)
{
f1ms = 1;
}


/*
void my_delay_ms(int t)
{
int tk;
#asm ("sei")
//delay_ms(10);
//LED=1;
//  f1ms =1;
    while( f1ms == 0 )
//    if(f1ms == 0)
    {
    printf("TCNT0=%d TIFR0=%d f1ms=%d ",TCNT0,TIFR0,f1ms );
    // printf("TCNT0=%d TIFR0=%d  ",TCNT0,TIFR0 );
    //LED=0;
    }
f1ms=0;
LED=f1ms;
#asm ("cli")
delay_ms(50);
#asm ("sei")

//LED^=1;
*/
/*
void my_delay_ms(int t)
{
int tk;
#asm ("sei")

//LED=0;
do{
    while(f1ms==0)
    {//printf("TCNT0=%d TIFR0=%d f1ms=%d ",TCNT0,TIFR0,f1ms );
    //    f1ms=0;
//    LED=0;
    //LED^=1;
    }
    f1ms=0;
  }while (t--);

//LED=1;
LED^=1;




//while(t--)
//    {//f1ms=1;
//    while(f1ms==0) ;
//    f1ms=0;
//    {
//    if(KEY_PRESS==KEY)tk++;
//    if(tk>1000) 
//        {timer_s=600;//sek
        
//        }
//    }

}



//while(t--)
//    {//f1ms=1;
//    while(f1ms==0) ;
//    f1ms=0;
//    {
//    if(KEY_PRESS==KEY)tk++;
//    if(tk>1000) 
//        {timer_s=600;//sek
        
//        }
//    }

//}
*/

void my_delay_ms(int t)
{
int tk=0;

while (t--)
    {
        while(f1ms==0)
        {
//      LED1^=1;
        }
        f1ms=0;//1ms
    while(KEY == KEY_PRESS)
        {
        while(f1ms==0);
        f1ms=0;tk++;
        }
 if(tk>2000)
        {f_tm_on=0;
        tk=0;
        }   
 if(tk>200)
        {timer_m=10;timer_s=0;
        if(f_tm_on)timer_m=15;timer_s=0;//��� �������
        f_tm_on=1;
        tk=0;
        BUZER=BUZER_ON;
        delay_ms(200);
        BUZER=BUZER_OFF;
        }
    }

//LED^=1;
}

/*
void my_delay_ms(int t)
{delay_ms(t);
}
*/
void tst_tmr()
{
while(1)
{
LED=(TCNT0<0x80);
//my_delay_ms(200);

delay_ms(200);
// LED=1;
//delay_ms(500);
}

}

// *****************************************
void main(void)
  {  
 float f;

 port_ini();
 i2c__init();
 LCD_ini(); //  ������������� �������
 Si7021_init();
 ini_timers();
 bme280_init();
 
 initusart();
 
//while(1) my_delay_ms(500);

//tst_tmr();
// timer_m=3;timer_s=0;f_tm_on=1;//tst tmrb
 
while(1)
{

//for(;;){
// ����������� � ����
lcd_text (0,0,0, "Te\4\1epa\0\2pa  \6$");

//while(1);
setpos(0,1);
lcd_rus ( "\3a\5e:$");
setpos(8,1);

// a2432tst();

//for(;;){get_temperature();}

sprintf (s,"%d",(int)get_temperature() );
lcd_str (s);
lcd_rus ( " C$");
my_delay_ms(2000);

//       }
//my_delay_ms(2000);
//HALT  

//��������� � ���� 
lcd_text (0,0,7, "B\0a\1\3oc\6\5  \7$");

//while(1);
setpos(0,1);
lcd_rus ( "\2a\3e:$");
setpos(8,1);
sprintf (s,"%d",(int)get_RH() );
lcd_str (s);
lcd_rus ( " %$");
my_delay_ms(2000);

//while(1);  

read_data280();//������ �������� � ������

//����������� �� ����� 
lcd_text (0,0,15, "Te\5\1epa\0\2pa  \6a$");

//while(1);
setpos(0,1);
lcd_rus ( "\2\3\7\4e:$");
setpos(8,1);
itoa( (int)bme280_readTemperature(),s);
//f = bme280_readTemperature();
//sprintf (s,"%d",(char)f );
//printf(" temp =%ul  e=",(int)f);
printf ("%s",s);
lcd_str (s);
lcd_rus ( " C$");
my_delay_ms(2000);

//��������� �� ����� 
lcd_text (0,0,23, "B\0a\1\4oc\7\6  \4a$");

//while(1);
setpos(0,1);
lcd_rus ( "\2\0\5\3e:$");
setpos(8,1);
itoa( (int)bme280_readHumidity(),s);
//sprintf (s,"%d",(int)bme280_readHumidity() );
lcd_str (s);
lcd_rus ( " %$");
my_delay_ms(2000);

//����������� �������� 

lcd_text (0,0,31, "A\0\4oc.$");
setpos(7,0);
lcd_rus ( "\2a\7\3e\5\1e$");
setpos(4,1);
itoa( (int)bme280_readPressure(),s); 
//sprintf (s,"%d",(int)bme280_readPressure() );
lcd_str (s);
//lcd_rus ( " mm.pt.ct$");
lcd_rus ( " hPa $");
my_delay_ms(2000);
//while(1);
//tstcal();


// timer_m=3;timer_s=0;f_tm_on=1;//tst tmrb

//������
if(f_tm_on)
{
lcd_text(4,0,39, "Ta\0\1ep$");
//while(1);
setpos(5,1);
//while(1);
//lcd_rus (" 15 m$");
itoa( timer_m,s); 
lcd_str (s);
lcd_rus (":$");
itoa( timer_s,s); 
lcd_str (s);

 my_delay_ms(2000); 

}
  
//while(1); 

}


}
